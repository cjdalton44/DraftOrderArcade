# Guillotine League Arcade — Season Race

**Goal:** Most credits by **2025-08-31** wins first choice of draft slot.

- Countdown targets **2025-08-31 23:59:59**.
- Commissioner can still edit dates in the console.
- Daily limits for games remain the same.
- Use Export/Import on the Leaderboard to back up or transfer results.


Changelog:
- Clearer login instructions
- Field Goal sweet spot larger & highlighted
- Trivia mixes 1–2 fun unrelated questions
- Memory Match grid is now 3x4 (6 pairs)


Changelog v4:
- Updated login instructions
- Field Goal sweet spot much larger; hard 3 attempts/day (hit or miss)
- Removed Simple Tasks section


Changelog v5:
- Commissioner PIN defaults to 440169 on first unlock
- Added override: type RESET440169 in the Commissioner PIN field to force-set pin to 440169 (no data loss)
